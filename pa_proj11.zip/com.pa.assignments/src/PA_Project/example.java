package PA_Project;

public class example {

	public static void main(String...args){
		String x = "aaru";
		int i =0;
		x=x+"genius";
		
		for(int j =0; j<9; j++) {
			
			
			if(i>7){
				x = x +"oooo";
			} else if(i<=6){
				x = x +"oooo";
			}
			x = x+"some";
			
		
		}
		String y = x+"some";
		
		
	}
	}
